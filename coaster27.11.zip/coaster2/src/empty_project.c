
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "em_device.h"
#include "em_chip.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_gpio.h"
#include "em_int.h"
#include "capsense.h"
#include "em_i2c.h"
#include "em_rtc.h"

#define TMP006_B0 -0.00006466
#define TMP006_B1 0.0000011255
#define TMP006_B2 0.000000011253


#define TMP006_C2 13.4
#define TMP006_TREF 298.15
#define TMP006_A2 -0.00001678
#define TMP006_A1 0.00175

#define TMP006_S0 1.44
double Tdie;
double TdieV;
double VobjV;
double Vobj;
double Temp,Temp2;
uint sTemp=50;
uint pollcount=0;
//////////
int mask=0;
uint bright=0;
double Tc[3];
double Tslope;
static uint8_t BufA[2];
static uint8_t BufB[2];

volatile I2C_TransferReturn_TypeDef status;

typedef enum {sleep,settemp,showtemp,gettemp,measure,notify} state;
state current_state=sleep;
/////////types//////////////
static I2C_TransferSeq_TypeDef seq ={
		.addr = 0x80,
		.buf[0].data = BufA,
		.buf[1].data = BufB
};
static I2C_Init_TypeDef I2INIT={
		.clhr = i2cClockHLRStandard,
		.enable= true,
		.freq= I2C_FREQ_STANDARD_MAX,
		.master=true,
		.refFreq=false

};
static RTC_Init_TypeDef RTCINI={
		.enable=0,
		.debugRun=1,
		.comp0Top=1
};
////////////////functions//////////////////


uint16_t concat(uint8_t a, uint8_t b){
    uint16_t c=b;
    c <<=8;
    c += a;

    return c;
}
void buzz(int period,int length){
	//period 25-30
   for (int l=0;l<length;l++){
	for (int g=0;g<period;g++){
	       	 GPIO_PinOutSet(0,8);

		}
	for (int g=0;g<period;g++){
	       	 GPIO_PinOutClear(0,8);

			}



   }



}

void ledctrl(int test){

     NVIC_DisableIRQ(RTC_IRQn);
 	RTC_Enable(0);
	 GPIO_PinModeSet(0,0,gpioModePushPull,0);//SER
	 GPIO_PinModeSet(4,10,gpioModePushPull,1);//N_OE
	 GPIO_PinModeSet(5,5,gpioModePushPull,0);//RCLK
	 GPIO_PinModeSet(5,3,gpioModePushPull,0);//SRCLK
	 GPIO_PinModeSet(5,4,gpioModePushPull,1);//N_SRCLR

      for (int i=0;i<8;i++){// send 8 bit
    	 GPIO_PinOutClear(5,5);//reset latch
    	 GPIO_PinOutClear(5,3); //SRCLK_low
    	 mask=1<<i;
    	 	 if((test&mask)!=0){
          	  GPIO_PinOutSet(0,0);// SER HIGH
    	 	 }else{
          	 GPIO_PinOutClear(0,0);// SER LOW

    	  }


    	  GPIO_PinOutSet(5,3);//Clock rising edge
       }
      GPIO_PinOutSet(5,5);//Latch data
      NVIC_EnableIRQ(RTC_IRQn);



}

float readdie(){
	//read Die temperature
    seq.buf[0].len=1; //send 1 bytes
    seq.buf[1].len=2; //receive 2 byte
    seq.buf[0].data[0]=0x01;
    seq.flags=I2C_FLAG_WRITE_READ;
    I2C_TransferInit(I2C0, &seq);
    status= I2C_TransferInit(I2C0, &seq);
        while (status==i2cTransferInProgress){

       	 status=I2C_Transfer(I2C0);
        }

        double TdieV= concat(BufB[1],BufB[0]);
        TdieV/=4;
        TdieV *= 0.03125; // convert to celsius

        TdieV += 273.15;  // to kelvin
        return TdieV;
};
float calcT(float T,float V){
	   double tdie_tref = T - TMP006_TREF;
	   double S = (1 + TMP006_A1*tdie_tref + TMP006_A2*tdie_tref*tdie_tref);
	   S *= TMP006_S0;
	   S /= 10000000;
	   S /= 10000000;
	   double Vos = TMP006_B0 + TMP006_B1*tdie_tref + TMP006_B2*tdie_tref*tdie_tref;
	   double fVobj = (V - Vos) + TMP006_C2*(V-Vos)*(V-Vos);
	   double Tobj = sqrt(sqrt(T * T * T * T + fVobj/S));
	   Tobj -= 273.15; // Kelvin to Celsius
	   return Tobj;
}
float readvol(){
	//read SensVoltage
    seq.buf[0].len=1; //send 1 bytes
    seq.buf[1].len=2; //receive 2 byte
    seq.buf[0].data[0]=0x00;
    seq.flags=I2C_FLAG_WRITE_READ;
    I2C_TransferInit(I2C0, &seq);
    status= I2C_TransferInit(I2C0, &seq);
        while (status==i2cTransferInProgress){
       	 status=I2C_Transfer(I2C0);
        }
        int16_t VobjTemp=concat(BufB[1],BufB[0]);
        float VobjV = (156.25*VobjTemp)/1000000000;  // 156.25 nV per LSB
        return VobjV;

};
void powerdown(){
	  GPIO_PinModeSet(gpioPortE, 12, gpioModeWiredAndPullUpFilter, 1);
	  GPIO_PinModeSet(gpioPortE, 13, gpioModeWiredAndPullUpFilter, 1);
	seq.buf[0].len=3;
	seq.buf[1].len=1;
	seq.buf[0].data[0]=0x02;
	seq.buf[0].data[1]=0b00000000;
	seq.buf[0].data[2]=0b00000000;
    seq.flags=I2C_FLAG_WRITE;

	 I2C_TransferInit(I2C0, &seq);
	    status= I2C_TransferInit(I2C0, &seq);
	        while (status==i2cTransferInProgress){
	       	 status=I2C_Transfer(I2C0);
	        }
	  	 GPIO_PinModeSet(gpioPortE, 12, gpioModeDisabled , 0);
	     GPIO_PinModeSet(gpioPortE, 13, gpioModeDisabled , 0);
	     GPIO_PinModeSet(4,11,gpioModeDisabled ,0);//RDY

	     GPIO_PinModeSet(0,2,gpioModeDisabled,0);

}
void readID(){

    seq.buf[0].len=1; //send 1 bytes
    seq.buf[1].len=2; //receive 2 byte
    seq.buf[0].data[0]=0xFF;
    seq.flags=I2C_FLAG_WRITE_READ;
    I2C_TransferInit(I2C0, &seq);
    status= I2C_TransferInit(I2C0, &seq);
        while (status==i2cTransferInProgress){
       	 status=I2C_Transfer(I2C0);
        }



}
void powerup(){

	  GPIO_PinModeSet(gpioPortE, 12, gpioModeWiredAndPullUpFilter, 1);
	  GPIO_PinModeSet(gpioPortE, 13, gpioModeWiredAndPullUpFilter, 1);
	  GPIO_PinModeSet(4,11,gpioModeInputPullFilter ,1);//RDY
	seq.buf[0].len=3;
	seq.buf[1].len=1;
	seq.buf[0].data[0]=0x02;
	seq.buf[0].data[2]=0x0;
	seq.buf[0].data[1]=0b01111001;//1 conv/sec
    seq.flags=I2C_FLAG_WRITE;

	 I2C_TransferInit(I2C0, &seq);
	    status= I2C_TransferInit(I2C0, &seq);
	        while (status==i2cTransferInProgress){
	       	 status=I2C_Transfer(I2C0);
	        }

}

void measureTemp(){
	  Tdie=readdie();
	  Vobj=readvol();
	  Temp=calcT(Tdie,Vobj)+3;
}
/////////////////main//////////////////////
int main(void)
{

  /* Chip errata */
  CHIP_Init();
  CMU_OscillatorEnable(cmuOsc_HFRCO,1,1);
  CMU_HFRCOBandSet (cmuHFRCOBand_14MHz  );

  CMU_ClockEnable(cmuClock_HFPER, true);
  CMU_ClockEnable(cmuClock_GPIO,1);
  CMU_ClockEnable(cmuClock_I2C0,1);
  CMU_ClockEnable(cmuClock_RTC, 1);
  CMU_OscillatorEnable(cmuOsc_LFRCO, true, 1);
  CMU_ClockSelectSet(cmuClock_LFA, cmuSelect_LFRCO);
  CMU_ClockEnable(cmuClock_LFA,1);
  CMU_ClockEnable(cmuClock_CORELE ,1);

  ///////I2C////////////////////////////
  GPIO_PortOutSet(0,0);
  GPIO_PortOutSet(1,0);
  GPIO_PortOutSet(2,0);
  GPIO_PortOutSet(3,0);
  GPIO_PortOutSet(4,0);
  GPIO_PortOutSet(5,0);

  I2C0->ROUTE = I2C_ROUTE_SDAPEN | I2C_ROUTE_SCLPEN | (6 << _I2C_ROUTE_LOCATION_SHIFT);
  I2C_Init(I2C0,&I2INIT);
  ////////////////RTC config//////////////
  RTC_Init(&RTCINI);
  RTC_CompareSet(0, 30000);
  RTC_IntEnable(RTC_IFC_COMP0);
  RTC_Enable(true);

 GPIO_PinModeSet(0,2,gpioModePushPull,0);//Boost Up converter
 GPIO_PinModeSet(0,8,gpioModePushPull,0);//Buzzer
 GPIO_PinModeSet(0,1,gpioModePushPull,0);// POWER on TMP and LED
 GPIO_PinModeSet(0,9,gpioModePushPull,0); //status LED
 GPIO_PinOutSet(0,2);//enable Boost-up converter

 NVIC_ClearPendingIRQ(GPIO_ODD_IRQn);
 GPIO_DriveModeSet(0,gpioDriveModeLow  );
  /////capsense
 current_state=sleep;
 CAPSENSE_Init();
powerdown();
	GPIO_PinOutSet(4,10);//OE disabled
	   GPIO_PinOutClear(0,9);//status LED

  while (1)
  {


switch (current_state){
     case sleep:
   	 //  GPIO_PinOutSet(4,10);//LED Out disable
	RTC_Enable(0);
	  //sleep mode, polling Button_0  each 5 second
     RTC_CompareSet(0,180000);
     NVIC_DisableIRQ(RTC_IRQn);
     NVIC_EnableIRQ(GPIO_ODD_IRQn);
	 CAPSENSE_Sense();
	 if(CAPSENSE_getPressed(BUTTON0_CHANNEL)){
         current_state=settemp; //set desired temp
		 buzz(28,100);
	     GPIO_PinOutSet(4,10);//OE disabled


	 }else{
		//go in EM2
		 RTC_CounterReset();
		 RTC_Enable(1);
		 NVIC_EnableIRQ(RTC_IRQn);
         EMU_EnterEM2(1);///sleep and wait to RTC Interrupt
	 }
	  break;

     case settemp:

   	  if(CAPSENSE_getPressed(BUTTON4_CHANNEL)){///reset to stand by
   			 buzz(42,200);
   			GPIO_PinOutSet(4,10);//OE disabled
            current_state=sleep;

   	  }
    	GPIO_PinOutSet(4,10);//OE disabled

    	ledctrl(sTemp);

  	    GPIO_PinOutClear(4,10);//OE

      RTC_CompareSet(0, 20000);
      CAPSENSE_Sense();
      ///measure temp, save as desired value
	  if(CAPSENSE_getPressed(BUTTON1_CHANNEL)){

		           NVIC_DisableIRQ(RTC_IRQn);
		           NVIC_EnableIRQ(GPIO_ODD_IRQn);

		      	   GPIO_IntConfig(4,11,0,1,1);
		      	   powerup();
		      	   EMU_EnterEM3(1); // wakes up through GPIO IR
		      	   measureTemp();
		      	   sTemp=Temp;
		         	GPIO_PinOutSet(4,10);//OE disabled
		         	ledctrl(sTemp);
		     	    GPIO_PinOutClear(4,10);//OE
			       buzz(28,100);
		      	   powerdown();
		      	   for(int i;i<1000;i++){//replace this with EM2 delay later


		      	   }
		         	GPIO_PinOutSet(4,10);//OE disabled
               current_state=measure;
	  }
    	 //get desired temp.Polling button 2 and 3 each 0,5 second. If no change is detected, set desired temp to previous saved value
	  if(CAPSENSE_getPressed(BUTTON2_CHANNEL)){
		  if(pollcount>0){
			  pollcount=pollcount-1;
		  }
		  sTemp=sTemp+1;
	      buzz(32,100);
      }else if(CAPSENSE_getPressed(BUTTON3_CHANNEL)){
		  buzz(22,100);
		  sTemp=sTemp-1;
		  if(pollcount>0){
			pollcount=pollcount-1;
		  }
      }else{
		  //if no button is touched, poll 10  times and go to measure mode
		  pollcount++;
		  if(pollcount==10){
		      buzz(29,100);
		      buzz(25,100);
		      buzz(29,100);
		      current_state=measure;
		      GPIO_PinOutSet(4,10);//
		      pollcount=0;
		  }
	  }
	  if(CAPSENSE_getPressed(BUTTON4_CHANNEL)){///reset to stand by
	    			 buzz(42,200);
	    			GPIO_PinOutSet(4,10);//OE disabled
	             current_state=sleep;

	    	  }
	  RTC_CounterReset();
	  RTC_Enable(1);
	  NVIC_EnableIRQ(RTC_IRQn);
	  EMU_EnterEM2(1);///sleep and wait to RTC Interrupt
      break;

     case measure:
         CAPSENSE_Sense();
   	          if(CAPSENSE_getPressed(BUTTON4_CHANNEL)){///reset to stand by
           			 buzz(42,200);
           	  	    GPIO_PinOutClear(4,10);//OE
                    current_state=sleep;

           	  }
    	  //measure temp each 5 seconds
           RTC_CompareSet(0, 360000); //measure Temp each 10s
           NVIC_DisableIRQ(RTC_IRQn);
           NVIC_EnableIRQ(GPIO_ODD_IRQn);

    	   GPIO_IntConfig(4,11,0,1,1);
    	   powerup();
    	   GPIO_PinOutSet(0,9);//status LED

    	   EMU_EnterEM3(1); // wakes up through GPIO IR
    	   GPIO_PinOutClear(0,9);//status LED

    	   measureTemp();
    	   powerdown();
           if(Temp<sTemp){
        	  current_state=notify;
           }else{

    	   RTC_CounterReset();
    	   RTC_Enable(1);
    	   NVIC_DisableIRQ(GPIO_ODD_IRQn);

    	   NVIC_EnableIRQ(RTC_IRQn);

    	   EMU_EnterEM2(1);///sleep and wait to RTC Interrupt
           }
	  break;
     case notify:
    	 for (int i=0;i<10;i++){
    	   RTC_CompareSet(0, 18000); //0,5s
    	   NVIC_DisableIRQ(RTC_IRQn);
    	   GPIO_PinOutSet(0,9);//status LED
    	   buzz(25,150);
    	   GPIO_PinOutClear(0,9);//status LED

    	   RTC_CounterReset();
    	   RTC_Enable(1);
           NVIC_EnableIRQ(RTC_IRQn);
    	   EMU_EnterEM2(1);
    	 }
    	   current_state=sleep;

    	   break;
     default:
    	 break;
  }




}
}





///RTC Interrupt
void RTC_IRQHandler(void) {
    RTC_IntClear(RTC_IFC_COMP0);
    RTC_IntEnable(RTC_IFC_COMP0);

}
//GPIO INterrupt
void GPIO_Unified_IRQ(void){
	uint32_t interruptMask = GPIO_IntGet();//clear interrupt flags
    GPIO_IntClear(interruptMask);


}
void GPIO_ODD_IRQHandler(void)
{
	GPIO_Unified_IRQ();
}
void GPIO_EVEN_IRQHandler(void)
{
	GPIO_Unified_IRQ();
}
